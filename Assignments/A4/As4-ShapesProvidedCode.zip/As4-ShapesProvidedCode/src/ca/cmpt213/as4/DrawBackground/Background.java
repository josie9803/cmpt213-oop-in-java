package ca.cmpt213.as4.DrawBackground;

import ca.cmpt213.as4.UI.Canvas;
import ca.cmpt213.as4.trivial_model.ShapeDescription;

public interface Background {
    void drawBackground(Canvas canvas, ShapeDescription description);
}
