package ca.cmpt213.as4.trivial_model;

import java.util.List;

public class ShapeWrapper {
    List<ShapeDescription> shapes;
}
