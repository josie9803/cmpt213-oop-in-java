package ca.cmpt213.as4.DrawBorder;

import ca.cmpt213.as4.UI.Canvas;
import ca.cmpt213.as4.trivial_model.ShapeDescription;

public interface Border {
    void drawBorder(Canvas canvas, ShapeDescription description);
}
