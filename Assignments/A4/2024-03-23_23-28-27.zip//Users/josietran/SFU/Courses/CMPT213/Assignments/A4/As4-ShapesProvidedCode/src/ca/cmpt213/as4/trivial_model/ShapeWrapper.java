package ca.cmpt213.as4.trivial_model;

import java.util.List;

/**
 * A simple wrapper for a list of ShapeDescription objects.
 */

public class ShapeWrapper {
    List<ShapeDescription> shapes;
}
