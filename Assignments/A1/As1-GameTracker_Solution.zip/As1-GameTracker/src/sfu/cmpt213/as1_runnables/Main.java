package sfu.cmpt213.as1_runnables;

/**
 * Start the application
 */
public class Main {
    public static void main(String[] args) {
        TextUI ui = new TextUI();
        ui.start();
    }
}
