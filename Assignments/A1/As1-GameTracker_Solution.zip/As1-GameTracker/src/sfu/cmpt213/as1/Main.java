package sfu.cmpt213.as1;

public class Main {
    public static void main(String[] args) {
        TextUI ui = new TextUI();
        ui.start();
    }
}
