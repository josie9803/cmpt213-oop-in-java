package cmpt213.as2;

import cmpt213.as2.model.ProductManager;
import cmpt213.as2.ui.TextUI;

/**
 * Start the application
 */
public class Main {
    public static void main(String[] args) {
        ProductManager model = new ProductManager();
        TextUI ui = new TextUI(model);
        ui.start();
    }
}
