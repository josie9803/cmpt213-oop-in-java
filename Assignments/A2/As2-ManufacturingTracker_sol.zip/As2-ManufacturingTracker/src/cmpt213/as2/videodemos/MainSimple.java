package cmpt213.as2.videodemos;

public class MainSimple {
    public static void main(String[] args){
        Location loc = new Location(49.45, 123.45);
        PetRock rck = new PetRock("Stoney", 25.5, loc);


    }
}
